export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // Keep all non-homepage routes/files untouched.
    if (url.pathname !== "/" && url.pathname !== "/index.html") {
      return env.ASSETS.fetch(request);
    }

    const indexResponse = await env.ASSETS.fetch(
      new Request(new URL("/index.html", url), request)
    );

    if (!indexResponse.ok) return indexResponse;

    let html = await indexResponse.text();

    // Read the existing Ads UI file without modifying index.html.
    const adsResponse = await env.ASSETS.fetch(
      new Request(new URL("/ads-ui.html", url), request)
    );

    let adsHTML = "";

    if (adsResponse.ok) {
      const adsFile = await adsResponse.text();

      const styleMatch = adsFile.match(
        /<style[^>]*>([\s\S]*?)<\/style>/i
      );
      const bodyMatch = adsFile.match(
        /<body[^>]*>([\s\S]*?)<\/body>/i
      );

      adsHTML = `
<style id="emojiMelaAdsOriginalStyle">
${styleMatch ? styleMatch[1] : ""}
</style>
<div id="emojiMelaAdsInjected">
${bodyMatch ? bodyMatch[1] : ""}
</div>`;
    }

    // Final visitor-facing controls.
    const finalCSS = `
<style id="emojiMelaFinalAdsCSS">
/* ===== EmojiMela visitor ads ===== */
#emojiMelaAdsInjected {
  width: 100%;
  max-width: 100%;
  margin: 0 auto;
  box-sizing: border-box;
  position: relative;
  z-index: 5;
}

#emojiMelaAdsInjected .ads-wrap {
  width: 100%;
  max-width: 1100px;
  margin: 14px auto;
  padding: 0 8px;
  box-sizing: border-box;
}

#emojiMelaAdsInjected .ad {
  position: relative;
  width: 100%;
  min-height: 92px;
  max-width: 100%;
  margin: 0 auto;
  padding: 26px 12px 10px;
  box-sizing: border-box;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  border-radius: 16px;
}

/* Small professional label */
#emojiMelaAdsInjected .ad::before {
  content: "ADVERTISEMENT";
  position: absolute;
  top: 7px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 8px;
  line-height: 1;
  font-weight: 700;
  letter-spacing: 1.2px;
  opacity: .55;
  white-space: nowrap;
  pointer-events: none;
}

#emojiMelaAdsInjected .ad-text {
  width: 100%;
  max-width: 728px;
  margin: 0 auto;
  line-height: 1.4;
}

#emojiMelaAdsInjected iframe,
#emojiMelaAdsInjected img,
#emojiMelaAdsInjected video,
#emojiMelaAdsInjected ins {
  max-width: 100% !important;
}

#emojiMelaAdsInjected .ad-mini {
  min-height: 96px;
}

#emojiMelaAdsInjected .ad-native {
  min-height: 120px;
}

/* Do not let the ad interfere with the promotional popup. */
#emojiMelaAdsInjected .ad {
  pointer-events: auto;
}

/* ===== Hide Admin Demo from normal visitors ===== */
/* Covers common IDs/classes/buttons without changing admin functionality. */
body:not(.admin-mode) #adminDemoModal,
body:not(.admin-mode) .admin-demo-btn,
body:not(.admin-mode) .admin-demo-button,
body:not(.admin-mode) button[onclick*="openAdminDemo"],
body:not(.admin-mode) a[onclick*="openAdminDemo"] {
  display: none !important;
}

/* If the Admin Demo button is fixed directly by inline styling. */
#adminDemoModal,
.admin-demo-btn,
.admin-demo-button {
  display: none !important;
}

/* ===== Mobile ===== */
@media (max-width: 767px) {
  #emojiMelaAdsInjected .ads-wrap {
    max-width: 100%;
    margin: 10px auto;
    padding: 0 5px;
  }

  #emojiMelaAdsInjected .ad {
    min-height: 88px;
    padding: 25px 8px 8px;
    border-radius: 15px;
  }

  #emojiMelaAdsInjected .ad-text {
    font-size: 13px;
  }

  #emojiMelaAdsInjected .ad-native {
    min-height: 112px;
  }
}

/* ===== Small phones ===== */
@media (max-width: 380px) {
  #emojiMelaAdsInjected .ads-wrap {
    padding: 0 4px;
  }

  #emojiMelaAdsInjected .ad {
    min-height: 82px;
    padding-left: 6px;
    padding-right: 6px;
  }

  #emojiMelaAdsInjected .ad-text {
    font-size: 12px;
  }
}

/* ===== Desktop / tablet ===== */
@media (min-width: 768px) {
  #emojiMelaAdsInjected .ads-wrap {
    margin: 20px auto;
    padding: 0 18px;
  }

  #emojiMelaAdsInjected .ad {
    min-height: 90px;
    padding: 28px 18px 12px;
    border-radius: 18px;
  }

  #emojiMelaAdsInjected .ad-mini {
    min-height: 90px;
  }

  #emojiMelaAdsInjected .ad-native {
    min-height: 180px;
  }
}
</style>`;

    const injection = adsHTML + finalCSS;

    // Put the ad directly before the Free Emojis section instead of
    // appending it at the very bottom of the document. This keeps the
    // mobile layout consistent: category tabs -> ad -> Free Emojis.
    const freeEmojiMatch = html.match(/.{0,220}(?:Free\s+Emojis|Free Emojis).{0,220}/i);

    if (freeEmojiMatch && freeEmojiMatch.index != null) {
      const insertAt = freeEmojiMatch.index;
      html = html.slice(0, insertAt) + injection + "\n" + html.slice(insertAt);
    } else if (html.includes("</body>")) {
      html = html.replace("</body>", injection + "\n</body>");
    } else {
      html += injection;
    }

    return new Response(html, {
      status: indexResponse.status,
      headers: {
        "Content-Type": "text/html; charset=UTF-8",
        "Cache-Control": "no-cache"
      }
    });
  }
};
