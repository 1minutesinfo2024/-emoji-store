export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // Keep every page except the homepage untouched.
    if (url.pathname !== "/" && url.pathname !== "/index.html") {
      return env.ASSETS.fetch(request);
    }

    // Get the original index.html without editing the file.
    const indexResponse = await env.ASSETS.fetch(
      new Request(new URL("/index.html", url), request)
    );

    if (!indexResponse.ok) return indexResponse;

    let html = await indexResponse.text();

    // Load the separate Ads UI file.
    const adsResponse = await env.ASSETS.fetch(
      new Request(new URL("/ads-ui.html", url), request)
    );

    let adsHTML = "";

    if (adsResponse.ok) {
      const adsFile = await adsResponse.text();

      const styleMatch = adsFile.match(
        /<style[^>]*>([\s\S]*?)<\/style>/i
      );
      const bodyMatch = adsFile.match(
        /<body[^>]*>([\s\S]*?)<\/body>/i
      );

      const adsCSS = styleMatch ? styleMatch[1] : "";
      const adsBody = bodyMatch ? bodyMatch[1] : "";

      adsHTML = `
<style id="emojiMelaAdsStyle">
${adsCSS}
</style>
<div id="emojiMelaAdsInjected">
${adsBody}
</div>`;
    }

    // Hide the visitor-facing Admin Demo button/modal.
    const adminHideCSS = `
<style id="emojiMelaAdminHide">
#adminDemoModal,
button[onclick="openAdminDemo()"] {
  display: none !important;
}
</style>`;

    const injection = adminHideCSS + adsHTML;

    // Inject only at the end of the homepage.
    if (html.includes("</body>")) {
      html = html.replace("</body>", injection + "\n</body>");
    } else {
      html += injection;
    }

    return new Response(html, {
      status: indexResponse.status,
      headers: {
        "Content-Type": "text/html; charset=UTF-8",
        "Cache-Control": "no-cache"
      }
    });
  }
};
