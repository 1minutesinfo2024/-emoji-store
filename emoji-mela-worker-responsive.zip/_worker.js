export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // Keep every page except the homepage untouched.
    if (url.pathname !== "/" && url.pathname !== "/index.html") {
      return env.ASSETS.fetch(request);
    }

    // Get the original index.html without editing the file.
    const indexResponse = await env.ASSETS.fetch(
      new Request(new URL("/index.html", url), request)
    );

    if (!indexResponse.ok) return indexResponse;

    let html = await indexResponse.text();

    // Load the separate Ads UI file.
    const adsResponse = await env.ASSETS.fetch(
      new Request(new URL("/ads-ui.html", url), request)
    );

    let adsHTML = "";

    if (adsResponse.ok) {
      const adsFile = await adsResponse.text();

      const styleMatch = adsFile.match(
        /<style[^>]*>([\s\S]*?)<\/style>/i
      );
      const bodyMatch = adsFile.match(
        /<body[^>]*>([\s\S]*?)<\/body>/i
      );

      const adsCSS = styleMatch ? styleMatch[1] : "";
      const adsBody = bodyMatch ? bodyMatch[1] : "";

      adsHTML = `
<style id="emojiMelaAdsStyle">
${adsCSS}
</style>
<div id="emojiMelaAdsInjected">
${adsBody}
</div>`;
    }

    // Visitor-facing Admin Demo must stay hidden.
    const adminHideCSS = `
<style id="emojiMelaAdminHide">
#adminDemoModal,
button[onclick="openAdminDemo()"] {
  display: none !important;
}
</style>`;

    // Professional, responsive advertisement container.
    // This is intentionally added after ads-ui.html CSS so these rules
    // provide the final mobile/desktop sizing and label treatment.
    const responsiveAdsCSS = `
<style id="emojiMelaResponsiveAds">
  #emojiMelaAdsInjected {
    width: 100%;
    max-width: 100%;
    margin: 0 auto;
    box-sizing: border-box;
  }

  #emojiMelaAdsInjected .ads-wrap {
    width: 100%;
    max-width: 1100px;
    margin: 18px auto;
    padding: 0 12px;
    box-sizing: border-box;
  }

  #emojiMelaAdsInjected .ad {
    position: relative;
    width: 100%;
    min-height: 100px;
    max-width: 100%;
    margin: 0 auto;
    padding: 28px 12px 12px;
    box-sizing: border-box;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    border-radius: 18px;
  }

  /* Clean "Advertisement" label */
  #emojiMelaAdsInjected .ad::before {
    content: "ADVERTISEMENT";
    position: absolute;
    top: 8px;
    left: 50%;
    transform: translateX(-50%);
    font-size: 9px;
    line-height: 1;
    font-weight: 700;
    letter-spacing: 1.1px;
    opacity: .62;
    white-space: nowrap;
    pointer-events: none;
  }

  #emojiMelaAdsInjected .ad-text {
    width: 100%;
    max-width: 728px;
    margin: 0 auto;
    line-height: 1.45;
  }

  #emojiMelaAdsInjected .ad-mini {
    min-height: 100px;
  }

  #emojiMelaAdsInjected .ad-native {
    min-height: 120px;
  }

  /* Ad/network iframe, image or script output must never overflow. */
  #emojiMelaAdsInjected iframe,
  #emojiMelaAdsInjected img,
  #emojiMelaAdsInjected video,
  #emojiMelaAdsInjected ins {
    max-width: 100% !important;
  }

  @media (min-width: 768px) {
    #emojiMelaAdsInjected .ads-wrap {
      padding: 0 20px;
      margin: 22px auto;
    }

    #emojiMelaAdsInjected .ad {
      min-height: 90px;
      padding: 30px 18px 14px;
      border-radius: 20px;
    }

    #emojiMelaAdsInjected .ad-mini {
      min-height: 90px;
    }

    #emojiMelaAdsInjected .ad-native {
      min-height: 180px;
    }
  }

  @media (max-width: 767px) {
    #emojiMelaAdsInjected .ads-wrap {
      padding: 0 8px;
      margin: 14px auto;
    }

    #emojiMelaAdsInjected .ad {
      min-height: 100px;
      padding: 28px 10px 12px;
      border-radius: 16px;
    }

    #emojiMelaAdsInjected .ad-text {
      font-size: 13px;
    }
  }

  @media (max-width: 360px) {
    #emojiMelaAdsInjected .ads-wrap {
      padding: 0 5px;
    }

    #emojiMelaAdsInjected .ad {
      min-height: 90px;
      padding-left: 8px;
      padding-right: 8px;
    }
  }
</style>`;

    const injection =
      adminHideCSS +
      adsHTML +
      responsiveAdsCSS;

    // Inject only at the end of the homepage.
    if (html.includes("</body>")) {
      html = html.replace("</body>", injection + "\n</body>");
    } else {
      html += injection;
    }

    return new Response(html, {
      status: indexResponse.status,
      headers: {
        "Content-Type": "text/html; charset=UTF-8",
        "Cache-Control": "no-cache"
      }
    });
  }
};
